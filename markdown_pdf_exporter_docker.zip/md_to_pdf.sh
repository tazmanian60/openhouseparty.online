#!/bin/sh

# Automatically export markdown files to versioned PDFs

for file in *.md; do
  base=$(basename "$file" .md)
  versioned_output="${base}_v$(date +%Y%m%d).pdf"
  pandoc "$file" -o "$versioned_output" --pdf-engine=xelatex --metadata title="Open House Party Report" --toc --highlight-style tango
  echo "✅ Generated: $versioned_output"
done
