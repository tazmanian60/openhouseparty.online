# Open House Party – Facts and Circumstances Statement (2024)

## Mission and Activities
Open House Party empowers individuals to create their dream homes and enhance their well-being through open-source, community-led resources. In 2024, activities included:
- Interviewing open-source pioneer Marcin Jakubowski from Open Source Ecology (available on YouTube).
- Updating the main website and launching self-hosted social platforms to share digital assets and licensing-aware content.
- Developing fabrication capacity via 3D printers and open-source hardware to manufacture kit-based housing components.
- Preparing educational and participatory workshops for hands-on open housing creation in 2025.

## Key Engagement Milestones
- Hosted a public video interview with Marcin Jakubowski.
- Published templates and donation forms via Zeffy.
- Drafted a supporter campaign via Patreon.
- OpenProject used to publish meeting notes and project plans.
- Began deployment of Open House Party’s Gitea site to centralize open-source digital assets.

## Public Support and Donor Base
- Estimated 17% public support over the past 5 years.
- Primary donors: Individuals via Zeffy and Patreon (records maintained externally).
- No significant grants exceeding IRS-defined thresholds have been received.

## Volunteer and Staff
- Only officer/colleague support presently recorded.
- Volunteer logs and stats will be tracked using updated platforms in the upcoming year.

## Public Benefit and Accessibility
- Open Gitea and OpenProject instances maintain open access to resources for community use.
- Future 3D-printed and CNC-manufactured housing components will be shared under open licenses with community input.
- Public-facing documentation will remain open for inspection and comment.

## Digital-First Compliance Note
Open House Party is a Michigan-registered nonprofit with a digital-first engagement strategy. It does not maintain an Ohio solicitation presence and is not required to register in other states unless thresholds are exceeded. Donations are open to all through Zeffy and Patreon with full IRS 501(c)(3) compliance.

This statement is submitted to meet the 10% Facts and Circumstances Test under Schedule A, Form 990, Part II, Line 17a.
